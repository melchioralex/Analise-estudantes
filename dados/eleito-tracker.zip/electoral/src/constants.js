export const PAUTA_TYPES = {
  CATEGORIA_A: 'categoria_a',
  CATEGORIA_B: 'categoria_b',
  CATEGORIA_C: 'categoria_c',
};

export const CATEGORIA_A_OPTIONS = ['A Favor', 'Contra', 'Neutro', 'Sem Dados'];

export const PAUTAS = [
  // ─── CATEGORIA A ───────────────────────────────────────────────
  {
    id: 'aborto',
    label: 'Aborto',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Direitos & Costumes',
  },
  {
    id: 'porte_armas',
    label: 'Porte de Armas',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Segurança Pública',
  },
  {
    id: 'legalizacao_maconha',
    label: 'Legalização da Maconha',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Direitos & Costumes',
  },
  {
    id: 'privatizacao',
    label: 'Privatização',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Economia',
  },
  {
    id: 'cameras_fardas',
    label: 'Câmeras em Fardas',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Segurança Pública',
  },
  {
    id: 'reducao_maioridade',
    label: 'Redução da Maioridade Penal',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Segurança Pública',
  },
  {
    id: 'ressocializacao',
    label: 'Ressocialização',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Segurança Pública',
  },
  {
    id: 'anistia',
    label: 'Anistia',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Política',
  },
  {
    id: 'cotas_raciais',
    label: 'Cotas Raciais',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Direitos & Costumes',
  },
  {
    id: 'cotas_trans',
    label: 'Cotas Trans',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Direitos & Costumes',
  },
  {
    id: 'homeschooling',
    label: 'Educação Domiciliar',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Educação',
  },
  {
    id: 'privatizacao_sus',
    label: 'Privatização do SUS',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Saúde',
  },
  {
    id: 'demarcacao_terras',
    label: 'Demarcação de Terras Indígenas',
    type: PAUTA_TYPES.CATEGORIA_A,
    group: 'Meio Ambiente',
  },

  // ─── CATEGORIA B ───────────────────────────────────────────────
  {
    id: 'reforma_tributaria',
    label: 'Reforma Tributária',
    type: PAUTA_TYPES.CATEGORIA_B,
    scaleMin: 1,
    scaleMax: 5,
    labelMin: 'Foco em Consumo',
    labelMax: 'Foco em Renda',
    group: 'Economia',
  },
  {
    id: 'transicao_energetica',
    label: 'Transição Energética',
    type: PAUTA_TYPES.CATEGORIA_B,
    scaleMin: 1,
    scaleMax: 5,
    labelMin: 'Foco em Fósseis',
    labelMax: 'Foco em Renováveis',
    group: 'Meio Ambiente',
  },

  // ─── CATEGORIA C ───────────────────────────────────────────────
  {
    id: 'bolsa_familia',
    label: 'Bolsa Família',
    type: PAUTA_TYPES.CATEGORIA_C,
    subtype: 'favor_contra',
    group: 'Assistência Social',
  },
  {
    id: 'pe_de_meia',
    label: 'Pé de Meia',
    type: PAUTA_TYPES.CATEGORIA_C,
    subtype: 'favor_contra',
    group: 'Educação',
  },
  {
    id: 'fidelidade_partidaria',
    label: 'Fidelidade Partidária',
    type: PAUTA_TYPES.CATEGORIA_C,
    subtype: 'percentage',
    unit: '%',
    group: 'Política',
  },
  {
    id: 'presenca_sessoes',
    label: 'Presença em Sessões',
    type: PAUTA_TYPES.CATEGORIA_C,
    subtype: 'percentage',
    unit: '%',
    group: 'Desempenho',
  },
  {
    id: 'extincao_supersalarios',
    label: 'Extinção de Supersalários',
    type: PAUTA_TYPES.CATEGORIA_C,
    subtype: 'favor_contra',
    group: 'Política',
  },
];

export const PAUTAS_BY_ID = Object.fromEntries(PAUTAS.map((p) => [p.id, p]));

export const PAUTA_GROUPS = [...new Set(PAUTAS.map((p) => p.group))];

export const PARTIDOS = [
  'PT', 'PL', 'MDB', 'PSDB', 'PP', 'PSD', 'Republicanos',
  'PDT', 'Solidariedade', 'Avante', 'Podemos', 'PSOL', 'PSB',
  'União Brasil', 'Cidadania', 'Novo', 'Rede',
];

export const ESTADOS = [
  { uf: 'AC', nome: 'Acre' },
  { uf: 'AL', nome: 'Alagoas' },
  { uf: 'AM', nome: 'Amazonas' },
  { uf: 'AP', nome: 'Amapá' },
  { uf: 'BA', nome: 'Bahia' },
  { uf: 'CE', nome: 'Ceará' },
  { uf: 'DF', nome: 'Distrito Federal' },
  { uf: 'ES', nome: 'Espírito Santo' },
  { uf: 'GO', nome: 'Goiás' },
  { uf: 'MA', nome: 'Maranhão' },
  { uf: 'MG', nome: 'Minas Gerais' },
  { uf: 'MS', nome: 'Mato Grosso do Sul' },
  { uf: 'MT', nome: 'Mato Grosso' },
  { uf: 'PA', nome: 'Pará' },
  { uf: 'PB', nome: 'Paraíba' },
  { uf: 'PE', nome: 'Pernambuco' },
  { uf: 'PI', nome: 'Piauí' },
  { uf: 'PR', nome: 'Paraná' },
  { uf: 'RJ', nome: 'Rio de Janeiro' },
  { uf: 'RN', nome: 'Rio Grande do Norte' },
  { uf: 'RO', nome: 'Rondônia' },
  { uf: 'RR', nome: 'Roraima' },
  { uf: 'RS', nome: 'Rio Grande do Sul' },
  { uf: 'SC', nome: 'Santa Catarina' },
  { uf: 'SE', nome: 'Sergipe' },
  { uf: 'SP', nome: 'São Paulo' },
  { uf: 'TO', nome: 'Tocantins' },
];

export const CARGOS_ESTADUAIS = [
  'Deputado Federal',
  'Deputado Estadual',
  'Senador (1ª vaga)',
  'Senador (2ª vaga)',
  'Governador / Vice',
];

export const CARGOS_FEDERAIS = ['Deputado Federal', 'Senador'];
