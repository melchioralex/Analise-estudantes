import React from 'react';
import { PAUTAS } from '../constants';
import PautaCell from './PautaCell';

function InstagramLink({ handle }) {
  if (!handle) return <span className="text-gray-300 text-xs">–</span>;
  return (
    <a
      href={`https://instagram.com/${handle}`}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center gap-1 text-pink-600 hover:text-pink-800 text-xs font-medium transition-colors"
    >
      <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
      </svg>
      @{handle}
    </a>
  );
}

function Avatar({ foto, nome }) {
  const initials = nome
    .split(' ')
    .slice(0, 2)
    .map((n) => n[0])
    .join('');

  return (
    <div className="flex items-center justify-center">
      {foto ? (
        <img
          src={foto}
          alt={nome}
          className="w-9 h-9 rounded-full object-cover border-2 border-white ring-1 ring-gray-200"
          onError={(e) => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'flex'; }}
        />
      ) : null}
      <div
        className="w-9 h-9 rounded-full bg-indigo-100 text-indigo-700 text-xs font-bold items-center justify-center"
        style={{ display: foto ? 'none' : 'flex' }}
      >
        {initials}
      </div>
    </div>
  );
}

const GROUP_COLORS = {
  'Direitos & Costumes': 'bg-purple-50 text-purple-700',
  'Segurança Pública':   'bg-red-50 text-red-700',
  'Economia':            'bg-amber-50 text-amber-700',
  'Meio Ambiente':       'bg-green-50 text-green-700',
  'Política':            'bg-blue-50 text-blue-700',
  'Educação':            'bg-sky-50 text-sky-700',
  'Saúde':               'bg-rose-50 text-rose-700',
  'Assistência Social':  'bg-teal-50 text-teal-700',
  'Desempenho':          'bg-gray-50 text-gray-700',
};

export default function CandidatosTable({ candidatos }) {
  if (candidatos.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center p-12">
        <div className="text-5xl mb-4">🔍</div>
        <p className="text-gray-500 font-medium">Nenhum candidato encontrado</p>
        <p className="text-gray-400 text-sm mt-1">Tente ajustar os filtros para ver resultados</p>
      </div>
    );
  }

  // Group pautas by group for colored headers
  const pautaGroups = [];
  let lastGroup = null;
  PAUTAS.forEach((p) => {
    if (p.group !== lastGroup) {
      pautaGroups.push({ group: p.group, count: 1, start: p.id });
      lastGroup = p.group;
    } else {
      pautaGroups[pautaGroups.length - 1].count++;
    }
  });

  return (
    <div className="flex-1 overflow-auto">
      <table className="min-w-max w-full border-collapse text-sm">
        <thead className="sticky top-0 z-20">
          {/* Group header row */}
          <tr>
            <th className="sticky left-0 z-30 bg-gray-900 border-r border-gray-700" colSpan={4}>
              <div className="h-6" />
            </th>
            {pautaGroups.map(({ group, count }) => {
              const colClass = GROUP_COLORS[group] ?? 'bg-gray-100 text-gray-600';
              return (
                <th
                  key={group}
                  colSpan={count}
                  className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1.5 text-center border-x border-white/30 ${colClass}`}
                >
                  {group}
                </th>
              );
            })}
          </tr>
          {/* Column header row */}
          <tr className="bg-gray-900 text-white">
            {/* Fixed columns */}
            <th className="sticky left-0 z-30 bg-gray-900 py-3 px-3 text-left text-xs font-semibold uppercase tracking-wider w-12 border-r border-gray-700">
              Foto
            </th>
            <th className="sticky left-12 z-30 bg-gray-900 py-3 px-3 text-left text-xs font-semibold uppercase tracking-wider min-w-[180px] border-r border-gray-700">
              Nome
            </th>
            <th className="py-3 px-3 text-left text-xs font-semibold uppercase tracking-wider min-w-[90px]">
              Partido
            </th>
            <th className="py-3 px-3 text-left text-xs font-semibold uppercase tracking-wider min-w-[130px] border-r border-gray-700">
              Instagram
            </th>
            {/* Dynamic pauta columns */}
            {PAUTAS.map((pauta) => (
              <th
                key={pauta.id}
                className="py-3 px-2 text-center text-[10px] font-semibold uppercase tracking-wider min-w-[80px] max-w-[100px] border-l border-gray-800"
                title={pauta.label}
              >
                <div className="leading-tight">{pauta.label}</div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {candidatos.map((c, idx) => {
            const isEven = idx % 2 === 0;
            const rowBg = isEven ? 'bg-white' : 'bg-gray-50/70';
            const hoverBg = 'hover:bg-indigo-50/40 transition-colors';

            return (
              <tr key={c.id} className={`${rowBg} ${hoverBg} group`}>
                {/* Foto */}
                <td className={`sticky left-0 z-10 py-2 px-3 border-r border-gray-200 ${rowBg}`}>
                  <Avatar foto={c.foto} nome={c.nome} />
                </td>
                {/* Nome + cargo */}
                <td className={`sticky left-12 z-10 py-2 px-3 border-r border-gray-200 ${rowBg}`}>
                  <div className="font-medium text-gray-900 whitespace-nowrap">{c.nome}</div>
                  <div className="text-[11px] text-gray-400 whitespace-nowrap">{c.cargo} {c.uf ? `· ${c.uf}` : ''}</div>
                </td>
                {/* Partido */}
                <td className="py-2 px-3">
                  <span className="inline-block px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 text-xs font-semibold border border-indigo-100">
                    {c.partido}
                  </span>
                </td>
                {/* Instagram */}
                <td className="py-2 px-3 border-r border-gray-200">
                  <InstagramLink handle={c.instagram} />
                </td>
                {/* Pautas */}
                {PAUTAS.map((pauta) => (
                  <td
                    key={pauta.id}
                    className="py-2 px-2 text-center border-l border-gray-100 group-hover:border-indigo-100"
                  >
                    <PautaCell value={c.pautas?.[pauta.id]} pauta={pauta} />
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
