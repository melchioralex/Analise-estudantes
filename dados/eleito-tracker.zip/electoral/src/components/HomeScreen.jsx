import React, { useState } from 'react';
import { ESTADOS } from '../constants';

export default function HomeScreen({ onSelect }) {
  const [mode, setMode] = useState(null); // 'federal' | 'estadual'
  const [uf, setUf] = useState('');

  const handleFederal = () => {
    setMode('federal');
    setUf('');
  };

  const handleEstadual = () => {
    setMode('estadual');
    setUf('');
  };

  const handleConfirm = () => {
    if (mode === 'federal') onSelect({ ambito: 'federal', uf: null });
    else if (mode === 'estadual' && uf) onSelect({ ambito: 'estadual', uf });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-indigo-950 to-gray-900 flex flex-col items-center justify-center p-6">

      {/* Logo / Header */}
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-indigo-500 flex items-center justify-center text-white text-xl">
            🗳️
          </div>
          <span className="text-white text-2xl font-bold tracking-tight">EleitoTracker</span>
        </div>
        <p className="text-indigo-200/70 text-sm mt-1">
          Transparência eleitoral · Eleições 2026
        </p>
      </div>

      {/* Main card */}
      <div className="w-full max-w-lg bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-8 space-y-6">
        <h1 className="text-white text-xl font-semibold text-center">
          Qual candidato você quer pesquisar?
        </h1>

        {/* Mode buttons */}
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={handleFederal}
            className={`flex flex-col items-center gap-3 p-6 rounded-xl border-2 transition-all ${
              mode === 'federal'
                ? 'border-indigo-400 bg-indigo-500/20 text-white'
                : 'border-white/10 bg-white/5 text-indigo-200 hover:border-indigo-400/50 hover:bg-white/10'
            }`}
          >
            <span className="text-3xl">🇧🇷</span>
            <div className="text-center">
              <div className="font-semibold text-sm">Federal</div>
              <div className="text-xs opacity-60 mt-0.5">Nacional</div>
            </div>
          </button>

          <button
            onClick={handleEstadual}
            className={`flex flex-col items-center gap-3 p-6 rounded-xl border-2 transition-all ${
              mode === 'estadual'
                ? 'border-indigo-400 bg-indigo-500/20 text-white'
                : 'border-white/10 bg-white/5 text-indigo-200 hover:border-indigo-400/50 hover:bg-white/10'
            }`}
          >
            <span className="text-3xl">📍</span>
            <div className="text-center">
              <div className="font-semibold text-sm">Estadual</div>
              <div className="text-xs opacity-60 mt-0.5">Por estado</div>
            </div>
          </button>
        </div>

        {/* UF selector */}
        {mode === 'estadual' && (
          <div className="animate-in fade-in slide-in-from-top-2 duration-200">
            <label className="block text-xs font-semibold text-indigo-200/70 uppercase tracking-wider mb-2">
              Selecione seu estado
            </label>
            <select
              value={uf}
              onChange={(e) => setUf(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-indigo-400 transition-colors"
            >
              <option value="" disabled className="bg-gray-900">Escolha um estado...</option>
              {ESTADOS.map((e) => (
                <option key={e.uf} value={e.uf} className="bg-gray-900">
                  {e.nome} ({e.uf})
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Confirm button */}
        {(mode === 'federal' || (mode === 'estadual' && uf)) && (
          <button
            onClick={handleConfirm}
            className="w-full py-3.5 bg-indigo-500 hover:bg-indigo-400 text-white font-semibold rounded-xl transition-all active:scale-95 text-sm"
          >
            Ver candidatos →
          </button>
        )}
      </div>

      <p className="text-white/20 text-xs mt-8 text-center">
        Dados ilustrativos para fins de demonstração
      </p>
    </div>
  );
}
