import React, { useState } from 'react';
import {
  PAUTAS,
  PAUTA_TYPES,
  PARTIDOS,
  CATEGORIA_A_OPTIONS,
  PAUTA_GROUPS,
} from '../constants';

function MultiCheckbox({ options, selected, onChange, colorMap }) {
  const toggle = (val) => {
    if (selected.includes(val)) onChange(selected.filter((v) => v !== val));
    else onChange([...selected, val]);
  };
  return (
    <div className="flex flex-wrap gap-1.5">
      {options.map((opt) => {
        const active = selected.includes(opt);
        const colors = colorMap?.[opt] ?? { active: 'bg-indigo-600 text-white border-indigo-600', inactive: 'border-gray-300 text-gray-600 hover:border-indigo-400' };
        return (
          <button
            key={opt}
            onClick={() => toggle(opt)}
            className={`px-2.5 py-1 rounded-full border text-xs font-medium transition-all ${active ? colors.active : colors.inactive}`}
          >
            {opt}
          </button>
        );
      })}
    </div>
  );
}

function RangeFilter({ value, onChange, min = 0, max = 100, unit = '%' }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs text-gray-500">
        <span>{min}{unit}</span>
        <span className="font-medium text-indigo-600">{value[0]}{unit} – {value[1]}{unit}</span>
        <span>{max}{unit}</span>
      </div>
      <div className="relative h-4 flex items-center">
        <div className="w-full h-1.5 bg-gray-200 rounded-full relative">
          <div
            className="absolute h-full bg-indigo-500 rounded-full"
            style={{ left: `${(value[0] / max) * 100}%`, width: `${((value[1] - value[0]) / max) * 100}%` }}
          />
        </div>
        <input
          type="range" min={min} max={max} value={value[0]}
          onChange={(e) => { const v = +e.target.value; if (v <= value[1]) onChange([v, value[1]]); }}
          className="absolute w-full h-1.5 opacity-0 cursor-pointer"
        />
        <input
          type="range" min={min} max={max} value={value[1]}
          onChange={(e) => { const v = +e.target.value; if (v >= value[0]) onChange([value[0], v]); }}
          className="absolute w-full h-1.5 opacity-0 cursor-pointer"
        />
      </div>
    </div>
  );
}

const CAT_A_COLORS = {
  'A Favor': { active: 'bg-emerald-600 text-white border-emerald-600', inactive: 'border-emerald-300 text-emerald-700 hover:border-emerald-500' },
  'Contra':  { active: 'bg-red-600 text-white border-red-600', inactive: 'border-red-300 text-red-700 hover:border-red-500' },
  'Neutro':  { active: 'bg-amber-500 text-white border-amber-500', inactive: 'border-amber-300 text-amber-700 hover:border-amber-500' },
  'Sem Dados': { active: 'bg-gray-400 text-white border-gray-400', inactive: 'border-gray-200 text-gray-400 hover:border-gray-400' },
};

function Section({ title, children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-gray-100 last:border-0">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex justify-between items-center py-3 px-1 text-left hover:bg-gray-50 transition-colors rounded"
      >
        <span className="text-xs font-semibold uppercase tracking-wider text-gray-500">{title}</span>
        <span className={`text-gray-400 text-sm transition-transform ${open ? 'rotate-180' : ''}`}>▾</span>
      </button>
      {open && <div className="pb-4 px-1 space-y-4">{children}</div>}
    </div>
  );
}

export default function FilterSidebar({ filters, onChange, onReset, totalVisible, totalAll }) {
  const setFilter = (key, val) => onChange({ ...filters, [key]: val });

  const catBPautas = PAUTAS.filter((p) => p.type === PAUTA_TYPES.CATEGORIA_B);
  const catCPautas = PAUTAS.filter((p) => p.type === PAUTA_TYPES.CATEGORIA_C && p.subtype === 'percentage');
  const catAPautas = PAUTAS.filter((p) => p.type === PAUTA_TYPES.CATEGORIA_A);
  const catCFavorPautas = PAUTAS.filter((p) => p.type === PAUTA_TYPES.CATEGORIA_C && p.subtype === 'favor_contra');

  const hasActiveFilters =
    filters.genero.length > 0 ||
    filters.partido.length > 0 ||
    Object.values(filters.pautasA).some((v) => v.length > 0) ||
    Object.values(filters.pautasB).some((v) => v[0] > 1 || v[1] < 5) ||
    Object.values(filters.pautasC_pct).some((v) => v[0] > 0 || v[1] < 100) ||
    Object.values(filters.pautasC_fc).some((v) => v.length > 0);

  return (
    <aside className="w-72 shrink-0 bg-white border-r border-gray-200 flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-gray-100 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-gray-900">Filtros</h2>
          <p className="text-xs text-gray-400 mt-0.5">
            {totalVisible} de {totalAll} candidato{totalAll !== 1 ? 's' : ''}
          </p>
        </div>
        {hasActiveFilters && (
          <button
            onClick={onReset}
            className="text-xs text-indigo-600 hover:text-indigo-800 font-medium transition-colors"
          >
            Limpar tudo
          </button>
        )}
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-1">

        <Section title="Gênero" defaultOpen>
          <MultiCheckbox
            options={['Masculino', 'Feminino', 'Não-binário']}
            selected={filters.genero}
            onChange={(v) => setFilter('genero', v)}
          />
        </Section>

        <Section title="Partido" defaultOpen>
          <div className="flex flex-wrap gap-1.5">
            {PARTIDOS.map((p) => {
              const active = filters.partido.includes(p);
              return (
                <button
                  key={p}
                  onClick={() => {
                    const next = active ? filters.partido.filter((x) => x !== p) : [...filters.partido, p];
                    setFilter('partido', next);
                  }}
                  className={`px-2 py-1 rounded text-xs font-medium border transition-all ${
                    active ? 'bg-indigo-600 text-white border-indigo-600' : 'border-gray-200 text-gray-600 hover:border-indigo-300'
                  }`}
                >
                  {p}
                </button>
              );
            })}
          </div>
        </Section>

        <Section title="Pautas — Posição">
          <p className="text-xs text-gray-400 -mt-2">Selecione uma ou mais posições por pauta</p>
          <div className="space-y-3">
            {catAPautas.map((pauta) => (
              <div key={pauta.id}>
                <p className="text-xs font-medium text-gray-700 mb-1">{pauta.label}</p>
                <MultiCheckbox
                  options={CATEGORIA_A_OPTIONS}
                  selected={filters.pautasA[pauta.id] ?? []}
                  onChange={(v) => setFilter('pautasA', { ...filters.pautasA, [pauta.id]: v })}
                  colorMap={CAT_A_COLORS}
                />
              </div>
            ))}
            {catCFavorPautas.map((pauta) => (
              <div key={pauta.id}>
                <p className="text-xs font-medium text-gray-700 mb-1">{pauta.label}</p>
                <MultiCheckbox
                  options={['A Favor', 'Contra', 'Neutro', 'Sem Dados']}
                  selected={filters.pautasC_fc[pauta.id] ?? []}
                  onChange={(v) => setFilter('pautasC_fc', { ...filters.pautasC_fc, [pauta.id]: v })}
                  colorMap={CAT_A_COLORS}
                />
              </div>
            ))}
          </div>
        </Section>

        <Section title="Pautas — Escala">
          <div className="space-y-4">
            {catBPautas.map((pauta) => {
              const val = filters.pautasB[pauta.id] ?? [1, 5];
              return (
                <div key={pauta.id}>
                  <p className="text-xs font-medium text-gray-700 mb-1">{pauta.label}</p>
                  <p className="text-[10px] text-gray-400 mb-2 flex justify-between">
                    <span>1 = {pauta.labelMin}</span>
                    <span>5 = {pauta.labelMax}</span>
                  </p>
                  <RangeFilter
                    value={val}
                    onChange={(v) => setFilter('pautasB', { ...filters.pautasB, [pauta.id]: v })}
                    min={1} max={5} unit=""
                  />
                </div>
              );
            })}
          </div>
        </Section>

        <Section title="Pautas — Percentuais">
          <div className="space-y-4">
            {catCPautas.map((pauta) => {
              const val = filters.pautasC_pct[pauta.id] ?? [0, 100];
              return (
                <div key={pauta.id}>
                  <p className="text-xs font-medium text-gray-700 mb-1">{pauta.label}</p>
                  <RangeFilter
                    value={val}
                    onChange={(v) => setFilter('pautasC_pct', { ...filters.pautasC_pct, [pauta.id]: v })}
                  />
                </div>
              );
            })}
          </div>
        </Section>

      </div>
    </aside>
  );
}
