import React from 'react';
import { PAUTA_TYPES } from '../constants';

// ─── Categoria A: A Favor / Contra / Neutro / Sem Dados ──────────
const CAT_A_CONFIG = {
  'A Favor':   { bg: 'bg-emerald-100', text: 'text-emerald-700', border: 'border-emerald-300', icon: '✓', label: 'A Favor' },
  'Contra':    { bg: 'bg-red-100',     text: 'text-red-700',     border: 'border-red-300',     icon: '✕', label: 'Contra' },
  'Neutro':    { bg: 'bg-amber-100',   text: 'text-amber-700',   border: 'border-amber-300',   icon: '–', label: 'Neutro' },
  'Sem Dados': { bg: 'bg-gray-100',    text: 'text-gray-400',    border: 'border-gray-200',    icon: '?', label: 'S/D' },
};

function CatACell({ value }) {
  const cfg = CAT_A_CONFIG[value] ?? CAT_A_CONFIG['Sem Dados'];
  return (
    <div className="flex justify-center">
      <span
        title={cfg.label}
        className={`inline-flex items-center justify-center w-7 h-7 rounded-full border text-xs font-bold ${cfg.bg} ${cfg.text} ${cfg.border}`}
      >
        {cfg.icon}
      </span>
    </div>
  );
}

// ─── Categoria B: Escala 1-5 ──────────────────────────────────────
function CatBCell({ value, pauta }) {
  if (value == null) return <span className="text-gray-300 text-xs">–</span>;
  const pct = ((value - 1) / 4) * 100;
  const color =
    pct <= 25  ? 'bg-orange-400' :
    pct <= 50  ? 'bg-amber-400'  :
    pct <= 75  ? 'bg-lime-500'   :
                 'bg-emerald-500';

  return (
    <div className="flex flex-col items-center gap-0.5 min-w-[64px]">
      <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${color}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="text-[10px] text-gray-500 font-medium tabular-nums">{value}/5</span>
    </div>
  );
}

// ─── Categoria C ─────────────────────────────────────────────────
function CatCCell({ value, pauta }) {
  if (value == null) return <span className="text-gray-300 text-xs">–</span>;

  if (pauta.subtype === 'percentage') {
    const color =
      value >= 80 ? 'text-emerald-700' :
      value >= 50 ? 'text-amber-700'   :
                    'text-red-600';
    return (
      <div className="flex flex-col items-center gap-0.5 min-w-[52px]">
        <span className={`text-sm font-bold tabular-nums ${color}`}>{value}%</span>
        <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full ${
              value >= 80 ? 'bg-emerald-500' : value >= 50 ? 'bg-amber-400' : 'bg-red-400'
            }`}
            style={{ width: `${value}%` }}
          />
        </div>
      </div>
    );
  }

  // favor_contra
  const cfg = CAT_A_CONFIG[value] ?? CAT_A_CONFIG['Sem Dados'];
  return (
    <div className="flex justify-center">
      <span
        title={cfg.label}
        className={`inline-flex items-center justify-center w-7 h-7 rounded-full border text-xs font-bold ${cfg.bg} ${cfg.text} ${cfg.border}`}
      >
        {cfg.icon}
      </span>
    </div>
  );
}

// ─── Export ───────────────────────────────────────────────────────
export default function PautaCell({ value, pauta }) {
  if (pauta.type === PAUTA_TYPES.CATEGORIA_A) return <CatACell value={value} />;
  if (pauta.type === PAUTA_TYPES.CATEGORIA_B) return <CatBCell value={value} pauta={pauta} />;
  if (pauta.type === PAUTA_TYPES.CATEGORIA_C) return <CatCCell value={value} pauta={pauta} />;
  return null;
}
