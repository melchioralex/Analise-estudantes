import React, { useState, useMemo } from 'react';
import HomeScreen from './components/HomeScreen';
import FilterSidebar from './components/FilterSidebar';
import CandidatosTable from './components/CandidatosTable';
import { candidatos as allCandidatos } from './mockData';
import { ESTADOS } from './constants';
import { useFilters } from './hooks/useFilters';

export default function App() {
  const [selection, setSelection] = useState(null); // { ambito, uf }
  const [search, setSearch] = useState('');

  // Filter candidatos by ambito/uf
  const candidatosPorSelecao = useMemo(() => {
    if (!selection) return [];
    if (selection.ambito === 'federal') {
      return allCandidatos.filter((c) => c.ambito === 'federal');
    }
    return allCandidatos.filter(
      (c) => c.ambito === 'estadual' && (!selection.uf || c.uf === selection.uf)
    );
  }, [selection]);

  const { filters, setFilters, filteredCandidatos, resetFilters } = useFilters(candidatosPorSelecao);

  // Text search on top of filters
  const displayCandidatos = useMemo(() => {
    if (!search.trim()) return filteredCandidatos;
    const q = search.toLowerCase();
    return filteredCandidatos.filter(
      (c) =>
        c.nome.toLowerCase().includes(q) ||
        c.partido.toLowerCase().includes(q) ||
        c.numero?.includes(q)
    );
  }, [filteredCandidatos, search]);

  if (!selection) {
    return <HomeScreen onSelect={setSelection} />;
  }

  const estadoNome = selection.uf
    ? (ESTADOS.find((e) => e.uf === selection.uf)?.nome ?? selection.uf)
    : null;

  return (
    <div className="flex flex-col h-screen bg-gray-50 font-sans">
      {/* Top bar */}
      <header className="bg-gray-900 text-white px-4 py-3 flex items-center gap-4 shrink-0 z-40">
        <button
          onClick={() => { setSelection(null); setSearch(''); }}
          className="flex items-center gap-1.5 text-indigo-300 hover:text-white text-sm transition-colors"
        >
          ← Início
        </button>

        <div className="h-5 w-px bg-white/20" />

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">
            {selection.ambito === 'federal' ? '🇧🇷 Federal' : `📍 ${estadoNome}`}
          </span>
          <span className="text-white/30 text-xs">·</span>
          <span className="text-white/50 text-xs">
            {displayCandidatos.length} candidato{displayCandidatos.length !== 1 ? 's' : ''}
          </span>
        </div>

        {/* Search */}
        <div className="ml-auto flex items-center">
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs">🔍</span>
            <input
              type="text"
              placeholder="Buscar por nome, partido ou número..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-white/10 border border-white/20 rounded-lg pl-8 pr-4 py-2 text-white placeholder-white/30 text-sm focus:outline-none focus:border-indigo-400 w-72 transition-colors"
            />
          </div>
        </div>
      </header>

      {/* Legend */}
      <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center gap-6 shrink-0 overflow-x-auto">
        <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider whitespace-nowrap">Legenda:</span>
        <div className="flex items-center gap-4 flex-wrap">
          {[
            { icon: '✓', bg: 'bg-emerald-100', text: 'text-emerald-700', label: 'A Favor' },
            { icon: '✕', bg: 'bg-red-100',     text: 'text-red-700',     label: 'Contra' },
            { icon: '–', bg: 'bg-amber-100',   text: 'text-amber-700',   label: 'Neutro' },
            { icon: '?', bg: 'bg-gray-100',    text: 'text-gray-400',    label: 'Sem Dados' },
          ].map(({ icon, bg, text, label }) => (
            <div key={label} className="flex items-center gap-1.5">
              <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-[10px] font-bold ${bg} ${text}`}>{icon}</span>
              <span className="text-xs text-gray-500">{label}</span>
            </div>
          ))}
          <div className="flex items-center gap-1.5">
            <div className="w-10 h-2 rounded-full bg-gradient-to-r from-orange-400 to-emerald-500" />
            <span className="text-xs text-gray-500">Escala 1→5</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-10 h-2 rounded-full bg-gradient-to-r from-red-400 to-emerald-500" />
            <span className="text-xs text-gray-500">% Percentual</span>
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="flex flex-1 overflow-hidden">
        <FilterSidebar
          filters={filters}
          onChange={setFilters}
          onReset={resetFilters}
          totalVisible={displayCandidatos.length}
          totalAll={candidatosPorSelecao.length}
        />
        <CandidatosTable candidatos={displayCandidatos} />
      </div>
    </div>
  );
}
