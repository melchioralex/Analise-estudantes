import { useState, useMemo } from 'react';
import { PAUTAS, PAUTA_TYPES } from '../constants';

const buildInitialFilters = () => {
  const pautasA = {};
  const pautasB = {};
  const pautasC_pct = {};
  const pautasC_fc = {};

  PAUTAS.forEach((p) => {
    if (p.type === PAUTA_TYPES.CATEGORIA_A) pautasA[p.id] = [];
    if (p.type === PAUTA_TYPES.CATEGORIA_B) pautasB[p.id] = [p.scaleMin, p.scaleMax];
    if (p.type === PAUTA_TYPES.CATEGORIA_C) {
      if (p.subtype === 'percentage') pautasC_pct[p.id] = [0, 100];
      if (p.subtype === 'favor_contra') pautasC_fc[p.id] = [];
    }
  });

  return { genero: [], partido: [], pautasA, pautasB, pautasC_pct, pautasC_fc };
};

const INITIAL_FILTERS = buildInitialFilters();

export function useFilters(allCandidatos) {
  const [filters, setFilters] = useState(INITIAL_FILTERS);

  const filteredCandidatos = useMemo(() => {
    return allCandidatos.filter((c) => {
      // Gênero
      if (filters.genero.length > 0 && !filters.genero.includes(c.genero)) return false;

      // Partido
      if (filters.partido.length > 0 && !filters.partido.includes(c.partido)) return false;

      // Categoria A
      for (const [id, selected] of Object.entries(filters.pautasA)) {
        if (selected.length === 0) continue;
        const val = c.pautas?.[id] ?? 'Sem Dados';
        if (!selected.includes(val)) return false;
      }

      // Categoria B
      for (const [id, [min, max]] of Object.entries(filters.pautasB)) {
        const pauta = PAUTAS.find((p) => p.id === id);
        if (!pauta) continue;
        if (min === pauta.scaleMin && max === pauta.scaleMax) continue; // default, skip
        const val = c.pautas?.[id];
        if (val == null) return false;
        if (val < min || val > max) return false;
      }

      // Categoria C — percentage
      for (const [id, [min, max]] of Object.entries(filters.pautasC_pct)) {
        if (min === 0 && max === 100) continue;
        const val = c.pautas?.[id];
        if (val == null) return false;
        if (val < min || val > max) return false;
      }

      // Categoria C — favor_contra
      for (const [id, selected] of Object.entries(filters.pautasC_fc)) {
        if (selected.length === 0) continue;
        const val = c.pautas?.[id] ?? 'Sem Dados';
        if (!selected.includes(val)) return false;
      }

      return true;
    });
  }, [allCandidatos, filters]);

  const resetFilters = () => setFilters(INITIAL_FILTERS);

  return { filters, setFilters, filteredCandidatos, resetFilters };
}
