# EleitoTracker · Candidatos 2026

Portal de visualização e filtragem de candidatos eleitorais com arquitetura modular em React + Tailwind CSS.

## 🚀 Instalação e execução

```bash
# 1. Entre na pasta do projeto
cd eleito-tracker

# 2. Instale as dependências
npm install

# 3. Rode o servidor de desenvolvimento
npm run dev

# 4. Acesse no navegador
# http://localhost:5173
```

## 📁 Estrutura de arquivos

```
src/
├── constants.js          ← TODAS as pautas e configurações (edite aqui para adicionar novas)
├── mockData.js           ← Dados dos candidatos
├── App.jsx               ← Componente raiz + topbar
├── index.jsx             ← Entry point React
├── index.css             ← Tailwind base styles
│
├── components/
│   ├── HomeScreen.jsx    ← Tela inicial (seleção de âmbito/estado)
│   ├── FilterSidebar.jsx ← Sidebar de filtros avançados
│   ├── CandidatosTable.jsx ← Tabela com sticky header e zebra stripes
│   └── PautaCell.jsx     ← Renderiza célula por tipo (A/B/C)
│
└── hooks/
    └── useFilters.js     ← Hook com useMemo para filtragem performática
```

## ➕ Como adicionar uma nova pauta

Abra `src/constants.js` e adicione um objeto no array `PAUTAS`:

```js
// Exemplo: Categoria A (A Favor / Contra / Neutro / Sem Dados)
{
  id: 'reforma_agraria',       // identificador único (snake_case)
  label: 'Reforma Agrária',    // nome exibido na tabela
  type: PAUTA_TYPES.CATEGORIA_A,
  group: 'Agricultura',        // agrupa colunas no cabeçalho
},

// Exemplo: Categoria B (Escala 1-5)
{
  id: 'industrializacao',
  label: 'Industrialização',
  type: PAUTA_TYPES.CATEGORIA_B,
  scaleMin: 1, scaleMax: 5,
  labelMin: 'Agro', labelMax: 'Indústria',
  group: 'Economia',
},

// Exemplo: Categoria C (Percentual)
{
  id: 'aprovacao_projetos',
  label: 'Aprovação de Projetos',
  type: PAUTA_TYPES.CATEGORIA_C,
  subtype: 'percentage',
  unit: '%',
  group: 'Desempenho',
},
```

Depois adicione o campo correspondente nos candidatos em `mockData.js`.

## ➕ Como adicionar um candidato

Em `mockData.js`, adicione um objeto seguindo o template:

```js
{
  id: 6,                                // único
  nome: 'Nome Completo',
  partido: 'PARTIDO',
  genero: 'Masculino',                  // 'Masculino' | 'Feminino' | 'Não-binário'
  cargo: 'Deputado Federal',
  uf: 'SP',                             // null para candidatos federais
  ambito: 'estadual',                   // 'federal' | 'estadual'
  numero: '12345',
  foto: 'https://...',                  // URL da foto ou null
  instagram: 'handle_sem_arroba',
  pautas: {
    // Preencha todos os campos de constants.js
    aborto: 'A Favor',
    reforma_tributaria: 3,
    presenca_sessoes: 85,
    // ...
  },
},
```

## 🎨 Tipos de células

| Tipo | Valores | Visualização |
|------|---------|--------------|
| Categoria A | `'A Favor'`, `'Contra'`, `'Neutro'`, `'Sem Dados'` | Ícone colorido (✓ ✕ – ?) |
| Categoria B | `1` a `5` | Barra de progresso colorida |
| Categoria C (%) | `0` a `100` | Número + barra de cor |
| Categoria C (Favor/Contra) | `'A Favor'`, `'Contra'`, `'Neutro'`, `'Sem Dados'` | Ícone colorido |

## 🔧 Build para produção

```bash
npm run build
# Output em dist/
```
